namespace EnemyConfigs
{
    [System.Serializable]
    public class EnemySpawnConfig 
    {
        public CreatureType EnemyType;
        public int Count;
        public int CurrentCount;
        public float SpawnTime;
        public float CurrentSpawnTime;
    }
}