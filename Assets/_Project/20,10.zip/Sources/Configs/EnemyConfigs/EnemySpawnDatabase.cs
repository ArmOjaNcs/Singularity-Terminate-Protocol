using System.Collections.Generic;
using UnityEngine;

namespace EnemyConfigs
{
    [CreateAssetMenu(fileName = "EnemySpawnDatabase", menuName = "Game/Enemy/Enemy Spawn Database")]
    public class EnemySpawnDatabase : ScriptableObject
    {
        public List<EnemyWaveSpawnConfig> Waves;
    }
}