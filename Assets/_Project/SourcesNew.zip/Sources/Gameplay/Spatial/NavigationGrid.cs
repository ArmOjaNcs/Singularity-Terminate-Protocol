using System;
using UnityEngine;

namespace Gameplay.Navigation
{
    public sealed class NavigationGrid : MonoBehaviour
    {
        [Header("Grid")]
        [SerializeField, Min(0.1f)]
        private float _cellSize = 1f;

        [SerializeField, Min(1)]
        private int _cellsX = 50;

        [SerializeField, Min(1)]
        private int _cellsZ = 50;

        [Header("Blocked Cells")]
        [SerializeField]
        private bool[] _blockedCells;

        [Header("Visualization")]
        [SerializeField]
        private bool _showGrid = true;

        [SerializeField]
        private bool _showBlockedCells = true;

        [SerializeField]
        private bool _showCellCoordinates = false;

        [SerializeField]
        private float _gizmoHeight = 0.05f;

        public float CellSize => _cellSize;
        public int CellsX => _cellsX;
        public int CellsZ => _cellsZ;

        private void OnValidate()
        {
            EnsureDataSize();
        }

        private void Awake()
        {
            EnsureDataSize();
        }

        // =========================================================
        // Runtime
        // =========================================================

        public bool IsWalkable(Vector3 worldPosition)
        {
            if (!TryGetCell(
                    worldPosition,
                    out int x,
                    out int z))
            {
                return false;
            }

            return IsWalkable(x, z);
        }

        public bool IsWalkable(
                Vector3 worldPosition,
                float radius)
        {
            if (radius <= 0f)
                return IsWalkable(worldPosition);

            if (!TryGetCell(
                    worldPosition,
                    out int centerX,
                    out int centerZ))
            {
                return false;
            }

            int cellRadius =
                Mathf.CeilToInt(radius / _cellSize);

            for (int x = centerX - cellRadius;
                 x <= centerX + cellRadius;
                 x++)
            {
                for (int z = centerZ - cellRadius;
                     z <= centerZ + cellRadius;
                     z++)
                {
                    if (!IsInside(x, z))
                        return false;

                    if (!IsBlocked(x, z))
                        continue;

                    Vector3 cellCenter =
                        GetCellCenter(x, z);

                    if (IsCircleOverlappingCell(
                            worldPosition,
                            radius,
                            cellCenter))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public bool IsWalkable(int x, int z)
        {
            if (!IsInside(x, z))
                return false;

            return !_blockedCells[GetIndex(x, z)];
        }

        public bool IsBlocked(int x, int z)
        {
            if (!IsInside(x, z))
                return true;

            return _blockedCells[GetIndex(x, z)];
        }

        public void SetBlocked(
            int x,
            int z,
            bool blocked)
        {
            if (!IsInside(x, z))
                return;

            _blockedCells[GetIndex(x, z)] = blocked;
        }

        public bool TryGetCell(
            Vector3 worldPosition,
            out int x,
            out int z)
        {
            Vector3 localPosition =
                transform.InverseTransformPoint(worldPosition);

            x = Mathf.FloorToInt(
                localPosition.x / _cellSize +
                _cellsX * 0.5f);

            z = Mathf.FloorToInt(
                localPosition.z / _cellSize +
                _cellsZ * 0.5f);

            return IsInside(x, z);
        }

        public Vector3 GetCellCenter(
            int x,
            int z)
        {
            if (!IsInside(x, z))
                throw new ArgumentOutOfRangeException();

            Vector3 localPosition = new Vector3(
                (x + 0.5f - _cellsX * 0.5f) * _cellSize,
                0f,
                (z + 0.5f - _cellsZ * 0.5f) * _cellSize);

            return transform.TransformPoint(localPosition);
        }

        public Vector3 GetGridSize()
        {
            return new Vector3(
                _cellsX * _cellSize,
                0f,
                _cellsZ * _cellSize);
        }

        // =========================================================
        // Gizmos
        // =========================================================

        private void OnDrawGizmos()
        {
            if (_cellSize <= 0f)
                return;

            if (_cellsX <= 0 || _cellsZ <= 0)
                return;

            if (_showGrid)
                DrawGridGizmos();

            if (_showBlockedCells)
                DrawBlockedGizmos();

#if UNITY_EDITOR
            if (_showCellCoordinates)
                DrawCoordinatesGizmos();
#endif
        }

        private void DrawGridGizmos()
        {
            Gizmos.color = new Color(
                1f,
                1f,
                1f,
                0.2f);

            for (int x = 0; x <= _cellsX; x++)
            {
                Vector3 start =
                    GetGridPoint(x, 0);

                Vector3 end =
                    GetGridPoint(x, _cellsZ);

                Gizmos.DrawLine(start, end);
            }

            for (int z = 0; z <= _cellsZ; z++)
            {
                Vector3 start =
                    GetGridPoint(0, z);

                Vector3 end =
                    GetGridPoint(_cellsX, z);

                Gizmos.DrawLine(start, end);
            }
        }

        private void DrawBlockedGizmos()
        {
            if (_blockedCells == null)
                return;

            Gizmos.color = new Color(
                1f,
                0.15f,
                0.15f,
                0.35f);

            for (int x = 0; x < _cellsX; x++)
            {
                for (int z = 0; z < _cellsZ; z++)
                {
                    if (!IsBlocked(x, z))
                        continue;

                    Vector3 center =
                        GetCellCenter(x, z);

                    Vector3 size = new Vector3(
                        _cellSize,
                        _gizmoHeight,
                        _cellSize);

                    Gizmos.DrawCube(
                        center +
                        transform.up *
                        (_gizmoHeight * 0.5f),
                        size);
                }
            }
        }

#if UNITY_EDITOR

        private void DrawCoordinatesGizmos()
        {
            GUIStyle style = new GUIStyle
            {
                fontSize = 10,
                alignment = TextAnchor.MiddleCenter
            };

            style.normal.textColor = Color.white;

            for (int x = 0; x < _cellsX; x++)
            {
                for (int z = 0; z < _cellsZ; z++)
                {
                    Vector3 center =
                        GetCellCenter(x, z) +
                        transform.up * 0.01f;

                    UnityEditor.Handles.Label(
                        center,
                        $"{x},{z}",
                        style);
                }
            }
        }

#endif

        private Vector3 GetGridPoint(
            int x,
            int z)
        {
            Vector3 localPosition =
                new Vector3(
                    (x - _cellsX * 0.5f) * _cellSize,
                    0f,
                    (z - _cellsZ * 0.5f) * _cellSize);

            return transform.TransformPoint(
                localPosition);
        }

        // =========================================================
        // Internal
        // =========================================================

        private bool IsCircleOverlappingCell(
                Vector3 circleCenter,
                float radius,
                Vector3 cellCenter)
        {
            Vector3 localCircleCenter =
                transform.InverseTransformPoint(
                    circleCenter);

            Vector3 localCellCenter =
                transform.InverseTransformPoint(
                    cellCenter);

            float half =
                _cellSize * 0.5f;

            float closestX =
                Mathf.Clamp(
                    localCircleCenter.x,
                    localCellCenter.x - half,
                    localCellCenter.x + half);

            float closestZ =
                Mathf.Clamp(
                    localCircleCenter.z,
                    localCellCenter.z - half,
                    localCellCenter.z + half);

            float dx =
                localCircleCenter.x - closestX;

            float dz =
                localCircleCenter.z - closestZ;

            return dx * dx + dz * dz <
                   radius * radius;
        }

        private bool IsInside(int x, int z)
        {
            return x >= 0 &&
                   x < _cellsX &&
                   z >= 0 &&
                   z < _cellsZ;
        }

        private int GetIndex(int x, int z)
        {
            return z * _cellsX + x;
        }

        private void EnsureDataSize()
        {
            int requiredSize =
                _cellsX * _cellsZ;

            if (_blockedCells != null &&
                _blockedCells.Length == requiredSize)
            {
                return;
            }

            bool[] oldData =
                _blockedCells;

            _blockedCells =
                new bool[requiredSize];

            if (oldData == null)
                return;

            int copyLength =
                Mathf.Min(
                    oldData.Length,
                    _blockedCells.Length);

            Array.Copy(
                oldData,
                _blockedCells,
                copyLength);
        }
    }
}