#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;

namespace Gameplay.Navigation
{
    [CustomEditor(typeof(NavigationGrid))]
    public sealed class NavigationGridEditor : Editor
    {
        private NavigationGrid _grid;

        private bool _editMode;
        private bool _blockMode = true;

        private int _brushSize = 1;

        private void OnEnable()
        {
            _grid = (NavigationGrid)target;

            SceneView.duringSceneGui += OnSceneGUI;
        }

        private void OnDisable()
        {
            SceneView.duringSceneGui -= OnSceneGUI;
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();

            EditorGUILayout.Space(12);

            EditorGUILayout.LabelField(
                "Navigation Editor",
                EditorStyles.boldLabel);

            EditorGUILayout.Space(5);

            _editMode = EditorGUILayout.Toggle(
                "Edit Mode",
                _editMode);

            if (!_editMode)
                return;

            EditorGUILayout.Space(5);

            _blockMode = EditorGUILayout.Toggle(
                "Block Cells",
                _blockMode);

            _brushSize = EditorGUILayout.IntSlider(
                "Brush Size",
                _brushSize,
                1,
                20);

            EditorGUILayout.Space(5);

            EditorGUILayout.HelpBox(
                "LMB � paint\n" +
                "Shift + LMB � erase\n" +
                "Mouse Wheel � brush size",
                MessageType.Info);

            EditorGUILayout.Space(5);

            if (GUILayout.Button("Clear All"))
            {
                ClearGrid();
            }
        }

        private void OnSceneGUI(SceneView sceneView)
        {
            if (!_editMode)
                return;

            if (_grid == null)
                return;

            Event currentEvent =
                Event.current;

            HandleInput(currentEvent);

            DrawEditorOverlay();

            sceneView.Repaint();
        }

        private void DrawEditorOverlay()
        {
            for (int x = 0;
                 x < _grid.CellsX;
                 x++)
            {
                for (int z = 0;
                     z < _grid.CellsZ;
                     z++)
                {
                    if (!_grid.IsBlocked(x, z))
                        continue;

                    DrawBlockedCell(x, z);
                }
            }
        }

        private void DrawBlockedCell(
            int x,
            int z)
        {
            Vector3 center =
                _grid.GetCellCenter(x, z);

            float half =
                _grid.CellSize * 0.5f;

            Vector3 up =
                _grid.transform.up;

            Vector3 right =
                _grid.transform.right;

            Vector3 forward =
                _grid.transform.forward;

            Vector3[] points =
            {
                center - right * half - forward * half,
                center - right * half + forward * half,
                center + right * half + forward * half,
                center + right * half - forward * half
            };

            Color fillColor =
                new Color(
                    1f,
                    0.1f,
                    0.1f,
                    0.35f);

            Color outlineColor =
                new Color(
                    1f,
                    0.2f,
                    0.2f,
                    0.9f);

            Handles.DrawSolidRectangleWithOutline(
                points,
                fillColor,
                outlineColor);
        }

        private void HandleInput(
            Event currentEvent)
        {
            if (currentEvent.type ==
                EventType.ScrollWheel)
            {
                _brushSize +=
                    currentEvent.delta.y > 0
                        ? -1
                        : 1;

                _brushSize =
                    Mathf.Clamp(
                        _brushSize,
                        1,
                        20);

                currentEvent.Use();

                return;
            }

            if (currentEvent.type !=
                    EventType.MouseDown &&
                currentEvent.type !=
                    EventType.MouseDrag)
            {
                return;
            }

            if (currentEvent.button != 0)
                return;

            Ray ray =
                HandleUtility.GUIPointToWorldRay(
                    currentEvent.mousePosition);

            Plane plane =
                new Plane(
                    _grid.transform.up,
                    _grid.transform.position);

            if (!plane.Raycast(
                    ray,
                    out float distance))
            {
                return;
            }

            Vector3 worldPosition =
                ray.GetPoint(distance);

            if (!_grid.TryGetCell(
                    worldPosition,
                    out int cellX,
                    out int cellZ))
            {
                return;
            }

            bool blocked =
                _blockMode;

            if (currentEvent.shift)
                blocked = false;

            Undo.RecordObject(
                _grid,
                blocked
                    ? "Block Navigation Cells"
                    : "Unblock Navigation Cells");

            Paint(
                cellX,
                cellZ,
                blocked);

            EditorUtility.SetDirty(
                _grid);

            currentEvent.Use();
        }

        private void Paint(
            int centerX,
            int centerZ,
            bool blocked)
        {
            int radius =
                _brushSize / 2;

            for (int x = -radius;
                 x <= radius;
                 x++)
            {
                for (int z = -radius;
                     z <= radius;
                     z++)
                {
                    _grid.SetBlocked(
                        centerX + x,
                        centerZ + z,
                        blocked);
                }
            }
        }

        private void ClearGrid()
        {
            Undo.RecordObject(
                _grid,
                "Clear Navigation Grid");

            for (int x = 0;
                 x < _grid.CellsX;
                 x++)
            {
                for (int z = 0;
                     z < _grid.CellsZ;
                     z++)
                {
                    _grid.SetBlocked(
                        x,
                        z,
                        false);
                }
            }

            EditorUtility.SetDirty(
                _grid);

            SceneView.RepaintAll();
        }
    }
}

#endif